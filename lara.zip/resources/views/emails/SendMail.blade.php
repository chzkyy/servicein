<x-mail::message>

{{$maildata['body']}}

Thanks,<br>
{{ config('app.name') }}
</x-mail::message>
