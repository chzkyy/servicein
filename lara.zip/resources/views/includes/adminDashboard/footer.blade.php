{{--  <!-- Footer -->  --}}
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; Copyright {{ date("Y"); }} | Powered by Servicein.</span>
        </div>
    </div>
</footer>
{{--  <!-- End of Footer -->  --}}
