<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Servicein">
    <meta name="author" content="Servicein">

    <title><?php echo $__env->yieldContent('title'); ?></title>

    <link href="<?php echo e(url('dashboard/css/sb-admin-2.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(url('dashboard/css/custome.css')); ?>" rel="stylesheet">

    
    <link href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.1.3/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="https://cdn.datatables.net/v/bs5/jq-3.6.0/dt-1.13.4/b-2.3.6/kt-2.9.0/r-2.4.1/sc-2.1.1/sl-1.6.2/datatables.min.css" rel="stylesheet"/>

    <?php echo $__env->make('includes.dashboard.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body id="page-top">

    
    <div id="wrapper">
        
        <div id="content-wrapper" class="d-flex flex-column">
            
            <div id="content">
                
            <nav class="navbar navbar-expand navbar-bg bg-white topbar mb-4 static-top shadow">
                <div class="container-fluid">
                    <a class="navbar-brand mx-5" href="<?php echo e(route('home')); ?>">
                        <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo">
                    </a>
                </div>
                <?php echo $__env->make('includes.adminDashboard.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>

            </div>
            

        </div>
        

    </div>
    

    
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php echo $__env->make('includes.adminDashboard.modal.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.dashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('includes.dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additional-script'); ?>



    <script src="<?php echo e(url('dashboard/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    
    <script src="<?php echo e(url('dashboard/vendor/jquery-easing/jquery.easing.min.js')); ?>"></script>
    
    <script src="<?php echo e(url('dashboard/js/sb-admin-2.min.js')); ?>"></script>

    
</body>

</html>
<?php /**PATH C:\laragon\www\servicein\resources\views/layouts/profileMerchant.blade.php ENDPATH**/ ?>