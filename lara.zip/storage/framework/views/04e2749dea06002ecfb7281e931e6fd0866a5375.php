<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Anda akan melanjutkan sebagai?')); ?></div>

                <div class="card-body">
                    <form method="POST" id="formRole" action="<?php echo e(route('store.role')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="container">
                            <div class="col-md-12 d-flex justify-content-center">
                                <div class="row mb-3">
                                    <div class="col-md-12">
                                        <button type="button" class="btn btn-primary" onclick="chooseRole('Admin')">
                                            <?php echo e(__('Admin Toko')); ?>

                                        </button>
                                        <button type="button" class="btn btn-primary" onclick="chooseRole('User')">
                                            <?php echo e(__('Customer')); ?>

                                        </button>
                                        <input type="hidden" id="role" name="role">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function chooseRole(role) {
        document.getElementById('role').value = role;
        document.getElementById('formRole').submit();
    }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/servicein_beta/resources/views/auth/choose-role.blade.php ENDPATH**/ ?>