<?php $__env->startSection('title'); ?>
    <?php echo e(__('View Invoice')); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<section class="min-vh-100 mt-5">
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="container pt-5">
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link text-decoration-none text-black fw-bold"><i class="fas fa-arrow-left"></i> Back</a>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card border border-1 rounded rounded-3" style="border-color: #655503 !important;">
                            <div class="card-header">
                                <h4 class="card-title fw-bold text-center"><?php echo e(__('Invoice')); ?></h4>
                            </div>
                            <div class="card-body navbar-bg">
                                <img class="img-fluid ml-5" src="<?php echo e(url('assets/img/logo.png')); ?>" alt="">
                            </div>
                            <div class="card-body">
                                <div class="container">
                                    <div class="col-md-12">
                                        <div class="row mt-4">
                                            <div class="col-md-7">
                                                <div class="merchant_name fw-semibold fs-5"><?php echo e($merchant['merchant_name']); ?></div>
                                                <div class="bussines-info my-2">
                                                    <div class="bussines-phone txt-gold fs-6 fw-semibold"><?php echo e(__('Bussiness Phone Number')); ?></div>
                                                    
                                                    
                                                    <div class="bussines-phone"><?php echo e(substr($merchant->phone_number, -12, -9) . " " . substr($merchant->phone_number, -9, -5) . " " . substr($merchant->phone_number, -5)); ?></div>
                                                </div>
                                                <div class="device-info">
                                                    <div class="device-service txt-gold fs-6 fw-semibold"><?php echo e(__("Service Device : ")); ?> <span class="fw-normal txt-black"><?php echo e($transaction->device_name); ?></span> </div>
                                                    <div class="device-service txt-gold fs-6 fw-semibold"><?php echo e(__("Transaction ID : ")); ?> <span class="fw-normal txt-black"><?php echo e($transaction->no_transaction); ?></span> </div>
                                                    <div class="device-service txt-gold fs-6 fw-semibold"><?php echo e(__("Status : ")); ?> <span class="fw-normal txt-black badge bg-success"><?php echo e($transaction->status); ?></span> </div>
                                                </div>
                                            </div>

                                            <div class="col-md-2">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <div class="txt-gold fw-semibold fs-6"><?php echo e(__('Warranty')); ?></div>
                                                        <div class="txt-black"><?php echo e(date("d M Y", strtotime($transaction->waranty))); ?></div>
                                                    </div>
                                                </div>
                                            </div>

                                            <div class="col-md-3">
                                                <?php if( $transaction['device_picture'] == null ): ?>
                                                    <img class="img-fluid" src="<?php echo e(url('assets/img/no-image.jpg')); ?>" alt="no_image" class="img-fluid card-img object-fit-fill">
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                        <div class="row mt-5">
                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-12">
                                                        <p class="fw-semibold txt-gold"><?php echo e(__('Description')); ?></p>
                                                        <div class="row my-2">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Merchant Note')); ?></div>
                                                            <div class="txt-black"><?php echo e($transaction->merchant_note); ?></div>
                                                        </div>

                                                        <div class="row my-2">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Detail Transaction')); ?></div>
                                                            <?php $__currentLoopData = $transaction_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dtl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <div class="txt-black col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6 text-wrap"><?php echo e($dtl->transaction_desc); ?></div>
                                                                    <div class="col-md-6">Rp. <?php echo e(number_format($dtl->transaction_price, 2, ',', '.')); ?></div>

                                                                </div>
                                                            </div>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>

                                                        <hr>

                                                        <div class="row my-2">
                                                            <div class="txt-black col-md-12">
                                                                <div class="row">
                                                                    <div class="col-md-6 fw-semibold txt-gold"><?php echo e(__('Total')); ?></div>
                                                                    <div class="col-md-6">Rp. <?php echo e(number_format($total, 2, ',', '.')); ?></div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>

                                            </div>

                                            <div class="col-md-6">
                                                <div class="row">
                                                    <div class="col-md-6">
                                                        
                                                        <p class="fw-semibold txt-gold"><?php echo e(__('Owner Information')); ?></p>

                                                        <div class="row my-2">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Device Owner')); ?></div>
                                                            <div><?php echo e(ucwords($transaction->fullname)); ?></div>
                                                        </div>

                                                        <div class="row my-2">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Phone Number')); ?></div>
                                                            <div><?php echo e($transaction->phone_number); ?></div>
                                                        </div>
                                                        <div class="row my-2">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Email')); ?></div>
                                                            <div><?php echo e($transaction->email); ?></div>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-6">
                                                        <p class="fw-semibold txt-gold"><?php echo e(__('Booking Detail')); ?></p>

                                                        <div class="row my-2">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Time')); ?></div>
                                                            <div><?php echo e(date("H:i", strtotime($transaction->booking_time)).__(' WIB')); ?></div>

                                                        </div>

                                                        <div class="row mt-2 mb-4">
                                                            <div class="fw-semibold txt-gold"><?php echo e(__('Date')); ?></div>
                                                            <div><?php echo e(date("l, d m Y", strtotime($transaction->booking_date))); ?></div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/customer/transaction/view-invoice.blade.php ENDPATH**/ ?>