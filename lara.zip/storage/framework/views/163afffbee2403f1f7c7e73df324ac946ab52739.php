<?php $__env->startSection('title'); ?>
    <?php echo e(__('Detail Transaction')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="mt-5 pt-md-5 min-vh-100">
    <div class="container-fluid">
        <div class="container">
            <div class="col-md-12">
                <div class="container pt-5">

                    <div class="row">
                        <div class="col-md-12">
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link text-decoration-none text-black fw-bold"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                    </div>

                    <div class="transaction-detail mt-5 mb-2">
                        <div class="row">
                            <div class="card my-2 transaction mb-2 border border-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-2 d-flex align-items-center">
                                            <?php if( $transaction->device_picture == null ): ?>
                                                <img src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="device_images" class="img-thumbnail img-fluid" style="width: 150px; height: auto;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset($transaction->device_picture)); ?>" alt="device_images" class="img-thumbnail img-fluid" style="width: 150px; height: auto;">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-8 d-flex align-items-center">
                                            <div class="row">
                                                <p class="fw-semibold"></p>
                                                <span>Device : <?php echo e($transaction->device_name); ?></span>
                                                <div>
                                                    <?php echo e(__("Status :")); ?>

                                                    <?php if($transaction->status == 'BOOKED'): ?>
                                                        <span class="badge bg-primary"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'DONE'): ?>
                                                        <span class="badge bg-success"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'CANCELLED'): ?>
                                                        <span class="badge bg-danger"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'ON PROGRESS'): ?>
                                                        <span class="badge bg-dark"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'ON PROGRESS - Need Confirmation'): ?>
                                                        
                                                        <?php
                                                            $status = explode(' - ', $transaction->status);
                                                        ?>
                                                        <span class="badge bg-dark"><?php echo e($status[0]); ?></span><?php echo e(__(" - ")); ?><span class="badge badge-warning"><?php echo e($status[1]); ?></span>
                                                    <?php elseif($transaction->status == 'ON COMPLAINT'): ?>
                                                        <span class="badge bg-info"><?php echo e($transaction->status); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <span>Transaction ID : <?php echo e($transaction->no_transaction); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="detail">
                        <div class="row">
                            <div class="card my-2 detail mb-2 border border-2">
                                <div class="card-body">
                                    <div class="row">
                                        <?php if($transaction->status != 'DONE'): ?>
                                            <div class="col-md-12 txt-gold fs-5">
                                                <?php echo e(__("Store in Charge :")); ?>

                                            </div>
                                        <?php else: ?>
                                            <div class="col-md-8 txt-gold fs-5">
                                                <?php echo e(__("Store in Charge :")); ?>

                                            </div>
                                            <div class="col-md-4 txt-gold fs-5">
                                                <?php echo e(__("Warranty :")); ?>

                                            </div>
                                        <?php endif; ?>

                                        <?php if($transaction->status != 'DONE'): ?>
                                            <div class="col-md-12 txt-gold fs-5 fw-bold mt-3">
                                                <?php echo e(ucwords($transaction->merchant_name)); ?>

                                            </div>
                                        <?php else: ?>
                                            <div class="col-md-8 txt-gold fs-5 fw-bold mt-3">
                                                <?php echo e(ucwords($transaction->merchant_name)); ?>

                                            </div>
                                            <div class="col-md-4 txt-gold fs-6 mt-1">
                                                <?php echo e(date('d M Y',strtotime($transaction->waranty))); ?>

                                            </div>
                                        <?php endif; ?>

                                        
                                        <?php if($transaction->status == 'BOOKED' || $transaction->status == 'ON PROGRESS' || $transaction->status == 'ON PROGRESS - Need Confirmation' || $transaction->status == 'ON COMPLAINT'): ?>
                                            <div class="col-md-12 mt-3 mb-4">
                                                <a href="<?php echo e(route('chat-merchant', ['id' => $merchant_id])); ?>" class="btn btn-custome text-decoration-none text-white fw-bold"><?php echo e(__('Chat Merchant')); ?></a>
                                            </div>
                                        <?php elseif($transaction->status == 'DONE'): ?>
                                            <div class="col-md-12 mt-3 mb-4">
                                                <a href="<?php echo e(route('view-invoice-customer', ['id' => $transaction->no_transaction])); ?>" class="btn btn-custome text-decoration-none text-white fw-bold"><?php echo e(__('View Invoice')); ?></a>
                                            </div>
                                        <?php endif; ?>

                                        
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-3 my-4">
                                                    
                                                    <p class="fw-semibold txt-gold"><?php echo e(__('Device Detail')); ?></p>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Device Brand')); ?></div>
                                                        <div><?php echo e(ucwords($transaction->brand)); ?></div>
                                                    </div>
                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Device Tyoe')); ?></div>
                                                        <div><?php echo e(ucwords($transaction->type)); ?></div>
                                                    </div>
                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Serial Number')); ?></div>
                                                        <div>
                                                            <?php echo e($transaction->serial_number); ?>

                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col-md-3 my-4">
                                                    <p class="fw-semibold"><?php echo e(__('Merchant Detail')); ?></p>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Email')); ?></div>
                                                        <div><?php echo e($transaction->email); ?></div>
                                                    </div>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Address')); ?></div>
                                                        <div><?php echo e($transaction->merchant_address); ?></div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3 my-4">
                                                    <p class="fw-semibold txt-gold"><?php echo e(__('Booking Detail')); ?></p>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Time')); ?></div>
                                                        <div><?php echo e(date("H:i", strtotime($transaction->booking_time)).__(' WIB')); ?></div>

                                                    </div>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Date')); ?></div>
                                                        <div><?php echo e(date("l, d M Y", strtotime($transaction->booking_date))); ?></div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3 my-4">
                                                    <p class="fw-semibold txt-gold"><?php echo e(__("Description")); ?></p>
                                                    
                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__("Merchant Note")); ?></div>
                                                        <?php if($transaction->merchant_note == null): ?>
                                                            <div><?php echo e(__('-')); ?></div>
                                                        <?php else: ?>
                                                            <div><?php echo e($transaction->merchant_note); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__("Customer Note")); ?></div>
                                                        <div><?php echo e($transaction->user_note); ?></div>
                                                    </div>
                                                </div>

                                                <?php if($transaction->status == 'BOOKED'): ?>
                                                    <div class="col-md-12 d-flex justify-content-center mt-5">
                                                        
                                                        <form action="<?php echo e(route('cancel-booking')); ?>" method="POST">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                            <button type="button" id="cancleBtn" class="btn btn-custome text-decoration-none text-white fw-bold"><?php echo e(__('Cancle Booking')); ?></button>
                                                        </form>
                                                    </div>
                                                <?php elseif($transaction->status == 'DONE'): ?>
                                                    <div class="col-md-12 d-flex justify-content-center">
                                                        <div class="row mt-5">
                                                            <?php if( date("Y-m-d") > date('Y-m-d',strtotime($transaction->waranty)) ): ?>
                                                                <?php if($review == null): ?>
                                                                    <div class="review col-md-12">
                                                                        <button type="button" class="btn btn-custome text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#reviewModal"><?php echo e(__('Review')); ?></button>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="review col-md-12">
                                                                        <button type="button" class="btn btn-custome text-decoration-none fw-bold" disabled><?php echo e(__('Review')); ?></button>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php else: ?>

                                                                <?php if($review == null): ?>
                                                                    <div class="review col-md-6">
                                                                        <button type="button" class="btn btn-custome text-decoration-none fw-bold" data-bs-toggle="modal" data-bs-target="#reviewModal"><?php echo e(__('Review')); ?></button>
                                                                    </div>
                                                                <?php else: ?>
                                                                    <div class="review col-md-6">
                                                                        <button type="button" class="btn btn-custome text-decoration-none fw-bold" disabled><?php echo e(__('Review')); ?></button>
                                                                    </div>
                                                                <?php endif; ?>

                                                                <div class="complaint col-md-6">
                                                                    <form action="<?php echo e(route('complaint')); ?>" method="POST">
                                                                        <?php echo csrf_field(); ?>
                                                                        <input type="hidden" name="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                                        <button type="button" id="complaintBtn" class="btn btn-custome-outline text-decoration-none fw-bold"><?php echo e(__('Complaint')); ?></button>
                                                                    </form>
                                                                </div>
                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>

                                            </div>
                                        </div>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('includes.customer.modal.createReview', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>



<?php $__env->startSection('additional-script'); ?>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/gh/kartik-v/bootstrap-star-rating@4.1.2/js/star-rating.min.js" type="text/javascript"></script>

    
    <script src="https://cdn.jsdelivr.net/gh/kartik-v/bootstrap-star-rating@4.1.2/themes/krajee-svg/theme.js"></script>

    
    <script src="https://cdn.jsdelivr.net/gh/kartik-v/bootstrap-star-rating@4.1.2/js/locales/LANG.js"></script>
    <script src="<?php echo e(asset('assets/js/image-uploader.min.js')); ?>"></script>

    <script>
        $('#cancleBtn').click(function () {
            Swal.fire({
                title: 'Are you sure?',
                text: "Are you sure you want to cancel this booking?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3c10fe5',
                confirmButtonText: 'Yes, cancel it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#cancleBtn').html('<i class="fa fa-spinner fa-spin"></i> Loading...');
                    $('#cancleBtn').addClass('disabled');

                    Swal.fire(
                        'Canceled!',
                        'Your booking has been canceled.',
                        'success'
                    ).then(() => {
                        $(this).parent().submit();
                    })
                }
            })
        })

        $('#complaintBtn').click(function() {
            Swal.fire({
                title: 'Are you sure?',
                text: "Are you sure you want to complaint?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3c10fe5',
                confirmButtonText: 'Yes, complaint it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#complaintBtn').html('<i class="fa fa-spinner fa-spin"></i> Loading...');
                    $('#complaintBtn').addClass('disabled');

                    Swal.fire({
                        title : 'Your complaint has been made!',
                        text: 'Please come to the store before the warranty periods end.',
                        icon : 'success',
                        showCancelButton: false,
                        confirmButtonColor: '#e3c10fe5',
                        confirmButtonText: 'Back to homepage'
                    }).then(() => {
                        $(this).parent().submit();
                    })
                }
            })
        })


        $('.input-images').imageUploader({
            imagesInputName: 'photos',
            maxSize: 2 * 1024 * 1024,
            maxFiles: 3
        });

        $("input[type='file']").on("change", function () {
            if(this.files[0].size > 2000000) {
                file = $(this)[0].files[0];
                //console.log(file);

                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: file.name + ' size must be less than 2 MB!',
                }).then((result) => {
                    // reload the page
                    location.reload();
                });

            }

            return false;
        });

        $("#rating").rating({
            min : 0,
            max : 5,
            step : 1,
            size : 'sm',
            showClear : false,
            showCaption : false,
        });



        $('#submit_review').click(function(e) {
            e.preventDefault();

            let form     = $('#photos')[0];
            let formData = new FormData(form);
            let file     = $("input[type='file']")[0].files[0];

            // get value from rating
            var rating   = $('#rating').val();
            var review   = $('#review').val();
            var reviewId = '';

            // console.log(file);
            // if file tidak ditemukan
            if(file != undefined) {
                if(file.size > 2000000) {
                    Swal.fire({
                        icon: 'error',
                        title: 'Oops...',
                        text: 'File size must be less than 2 MB!',
                    })

                    return false;
                }

                $.ajax({
                    url : "<?php echo e(route('add-review')); ?>",
                    type : "POST",
                    data : formData,
                    contentType: false,
                    processData: false,
                    success : function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Your review has been added!',
                        }).then((result) => {
                            // reload the page
                            location.reload();
                        });
                    },
                    error : function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong!',
                        })
                    }
                })
            }
            else {
                $.ajax({
                    url : "<?php echo e(route('add-review')); ?>",
                    type : "POST",
                    data : formData,
                    contentType: false,
                    processData: false,
                    success : function(response) {
                        Swal.fire({
                            icon: 'success',
                            title: 'Success',
                            text: 'Your review has been added!',
                        }).then((result) => {
                            // reload the page
                            location.reload();
                        });
                    },
                    error : function(xhr) {
                        Swal.fire({
                            icon: 'error',
                            title: 'Oops...',
                            text: 'Something went wrong!',
                        })
                    }
                })
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/customer/transaction/detail-transaction.blade.php ENDPATH**/ ?>