<?php $__env->startSection('title', 'Verify Account'); ?>
<?php $__env->startSection('content'); ?>
<section class="vh-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-5 px-0 d-none d-sm-block">
                
                <div class="d-flex align-item-center">
                    <div class="col-12">
                        <div class="d-flex justify-content-start">
                            <div class="logo">
                                <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo" class="logo-img mx-5 mt-4">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="w-100 vh-100 c-img-login"></div>
                
                <div class="d-flex align-item-center">
                    <div class="col-12">
                        <div class="d-flex justify-content-center">
                            <div class="qoute"></div>
                            <div class="text mt-4">
                                <p><?php echo e(__("We understand the importance of your laptops and the impact it has on your daily life, which is why we offer fast and reliable services such as repairs, upgrades, and maintenance. Our goal is to provide you with exceptional service that exceeds your expectations.")); ?></p>
                            </div>
                            <div class="vector"></div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-md-7 text-black">
                <div class="d-flex d-md-none align-items-center justify-content-center py-5 mt-4 pb-5 mb-5">
                    <img src="<?php echo e(url('assets/img/Logo2.png')); ?>" alt="logo" class="logo-img">
                </div>

                <div class="d-none d-md-flex align-item-center px-5 mt-2 pt-4 mb-3 pb-3">
                    <div class="col-12">
                        <div class="d-flex justify-content-end">
                            <div class="create-account">
                                <span class="text-create-account txt-secondary"> <?php echo e(__('Verify Email Address')); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center">
                    <div class="col-md-12">
                        <div class="d-flex text-center justify-content-center align-content-center">
                            <div class="col-md-6 col-md-offset-3">

                                <div class="icon-verify mb-5 mt-5">
                                    <img src="<?php echo e(url('assets/img/newsletter.png')); ?>" class="img-fluid img-eVerify" alt="icon-newsletter">
                                </div>

                                <?php if(session('resent')): ?>
                                    <div class="alert alert-success" role="alert">
                                        <?php echo e(__('A fresh verification link has been sent to your email address.')); ?>

                                    </div>
                                <?php endif; ?>

                                <span class="txt-secondary text-center"><?php echo e(__('Before proceeding, please check your email for a verification link. If you didn’t receive the email.')); ?></span>

                                <form class="d-inline" method="POST" action="<?php echo e(route('verification.resend')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-link fw-semibold p-0 m-0 align-baseline"><?php echo e(__('Click here to request another')); ?></button>.
                                </form>
                            </div>

                            
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein_beta\resources\views/auth/verify.blade.php ENDPATH**/ ?>