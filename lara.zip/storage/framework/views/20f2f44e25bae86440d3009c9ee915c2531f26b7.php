<div class="modal fade" id="addDevice" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg modal-dialog-centered">
        <div class="modal-content rounded-1 border-0 text-black">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Add Device')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form action="<?php echo e(route('add-device')); ?>" method="POST" id="form_addDevice" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="device_name" class="form-label"><?php echo e(__('Device Name')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['device_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="device_name" id="device_name" placeholder="Input Your Device Name" required autofocus>
                            </div>

                            <div class="form-group mb-2">
                                <label for="type" class="form-label"><?php echo e(__('Device Type')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="type" id="type" placeholder="Input Your Device Type" required autofocus>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="brand" class="form-label"><?php echo e(__('Device Brand')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="brand" id="brand" placeholder="Input Your Device Brand" required autofocus>
                            </div>

                            <div class="form-group mb-2">
                                <label for="serial_number" class="form-label"><?php echo e(__('Device Serial Number')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="serial_number" id="serial_number" placeholder="Input Your Device Serial Number" required autofocus>
                                <small  class="text-muted txt-fz-12">
                                    <?php echo e(__("*If you don't know your device serial number fill 0")); ?>

                                </small>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label"><?php echo e(__("Device Picture")); ?></label>
                                <img class="img-fluid img-thumbnail img-preview my-4">
                                <input type="file" class="d-block form-control <?php $__errorArgs = ['device_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="device_image" name="device_image" onchange="preview_AddDevice()" accept="image/*">
                                <small class="form-text text-muted">Maximum size 2MB</small>
                            </div>
                        </div>

                        <hr class="mt-5">
                        <div class="col-md-12">
                            <div class="d-flex justify-content-center align-content-center">
                                <button type="submit" class="btn btn-custome col-md-2 mx-auto" id="submit_addDevices">Add Device</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\servicein\resources\views/includes/customer/modal/addDevice.blade.php ENDPATH**/ ?>