<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="description" content="Servicein">
    <meta name="author" content="Servicein">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('includes.dashboard.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo $__env->make('includes.dashboard.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('content'); ?>
    <?php echo $__env->make('includes.dashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additional-script'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\servicein_beta\resources\views/layouts/dashboard.blade.php ENDPATH**/ ?>