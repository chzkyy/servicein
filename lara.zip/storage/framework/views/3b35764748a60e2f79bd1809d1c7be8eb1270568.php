<?php $__env->startSection('title'); ?>
    <?php echo e(__('Register')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="vh-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-5 px-0 d-none d-sm-block">
                    
                    <div class="d-flex align-item-center">
                        <div class="col-12">
                            <div class="d-flex justify-content-start">
                                <div class="logo">
                                    <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo" class="logo-img mx-5 mt-4">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="w-100 vh-100 c-img-login"></div>

                    
                    <div class="d-flex align-item-center">
                        <div class="col-12">
                            <div class="d-flex justify-content-center">
                                <div class="qoute"></div>
                                <div class="text mt-4">
                                    <p><?php echo e(__("We understand the importance of your laptops and the impact it has on your daily life, which is why we offer fast and reliable services such as repairs, upgrades, and maintenance. Our goal is to provide you with exceptional service that exceeds your expectations.")); ?></p>
                                </div>
                                <div class="vector"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-7 text-black">
                    <div class="d-flex align-item-center px-5 mt-2 pt-4">
                        <div class="col-12">
                            <div class="d-none d-sm-flex justify-content-between">
                                <div class="back">
                                    <a href="<?php echo e(route('login')); ?>" class="txt-secondary fw-semibold"><i class="fa fa-chevron-left fa-xs" aria-hidden="true"></i> <?php echo e(__('Back')); ?></a>
                                </div>
                                <div class="create-account">
                                    <span class="text-create-account"> <?php echo e(__('Already have an account?')); ?> <a href="<?php echo e(route('login')); ?>" class="txt-primary fw-semibold"><?php echo e(__('Sign in')); ?></a></span>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex d-md-none align-items-center justify-content-center py-5 mb-4 pb-4">
                        <img src="<?php echo e(url('assets/img/Logo2.png')); ?>" alt="logo" class="logo-img">
                    </div>

                    <div class="d-flex align-items-center px-5 ms-xl-3 mt-3 pt-3">
                        <div class="row">
                            <span class="text-login"><?php echo e(__('Register Account')); ?></span>
                            <span class="desc-login"><?php echo e(__('Please fill your account information below')); ?></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center px-5 ms-xl-4 mt-3 pt-3 pt-xl-0 mt-xl-n5">
                        <div class="col-md-8">
                            <form action="<?php echo e(route('register')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <div class="form-group">
                                    <label for="username" class="form-label"><?php echo e(__('Username')); ?></label>
                                    <input type="text" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-lg" id="username" name="username"
                                        value="<?php echo e(old('username')); ?>" placeholder="Enter username" required
                                        autocomplete="username" autofocus />
                                </div>

                                <div class="form-group mt-2">
                                    <label for="email" class="form-label"><?php echo e(__('Email address')); ?></label>
                                    <input type="email"
                                        class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-lg"
                                        id="email" name="email" value="<?php echo e(old('email')); ?>"
                                        placeholder="Enter email address" required autocomplete="email" autofocus />
                                </div>

                                <div class="form-group mt-2">
                                    <label for="password" class="form-label"><?php echo e(__('Password')); ?></label>
                                    <div class="input-group">
                                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-lg input-group"
                                            id="password" name="password" required autocomplete="current-password"
                                            placeholder="Enter your password" />

                                        <div class="input-group-append input-group-text" onclick="password()">
                                            <i class="far fa-eye" id="eye"></i>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mt-2">
                                    <label for="password-confirm" class="form-label"><?php echo e(__('Confirm Password')); ?></label>
                                    <div class="input-group">
                                        <input type="password" class="form-control form-control-lg" id="password_confirmation"
                                            name="password_confirmation" required autocomplete="new-password"
                                            placeholder="Enter your password" />

                                        <div class="input-group-append input-group-text" onclick="password_confirmation()">
                                            <i class="far fa-eye" id="eye_confirmation"></i>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mt-3 term">
                                    <input class="form-check-input checkbox <?php $__errorArgs = ['tnc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" type="checkbox" name="tnc" id="tnc" <?php echo e(old('tnc') ? 'checked' : ''); ?> onclick="return true" />
                                    <label for="tnc" class="checkbox-label txt-primary fw-semibold"><?php echo e(__('I agree to the')); ?>

                                        
                                        <a data-bs-toggle="modal" data-bs-target="#terms-and-conditions" class="txt-primary fw-bold"><?php echo e(__('Terms and Conditions')); ?></a>
                                    </label>
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit" class="col-12 btn btn-custome btn-lg btn-block"><?php echo e(__('Register')); ?></button>
                                </div>

                                <div class="form-group mt-4">
                                    <a href="<?php echo e(route('redirect')); ?>"
                                        class="col-12 btn btn-with-google btn-lg btn-block btn-google">
                                        <img src="<?php echo e(url('assets/img/icons_google.png')); ?>" alt="google"
                                            class="google-icon">
                                        Register with Google
                                    </a>
                                </div>

                                <div class="create-account text-center my-4 d-block d-md-none text-center">
                                    <span class="text-create-account"> <?php echo e(__('Already have an account?')); ?> <a href="<?php echo e(route('login')); ?>" class="txt-primary fw-semibold"><?php echo e(__('Sign in')); ?></a></span>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <?php echo $__env->make('policy.terms-and-conditions', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein_beta\resources\views/auth/register.blade.php ENDPATH**/ ?>