<?php $__env->startSection('title'); ?>
    <?php echo e(__('Search Merchant')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        
        <div class="container-fluid pt-5">
            <div class="row">
                <div class="col-md-12 mt-5 pt-2">
                    <div class="container">
                        <div class="title">
                            <span class="fw-semibold "><?php echo e(__("Showing results for")); ?></span>
                            <span class="fw-semibold">"<?php echo e($search); ?>"</span>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-12">
                <div class="container">
                    <div class="row justify-content-center align-items-center txt-third mt-5">
                        <div class="card mt-2 mb-4 border-2">
                            <div class="card-body">
                                <div class="row d-flex justify-content-center align-items-center" id="data-container">

                                        <?php if( count($transaction) > 0): ?>
                                            <?php for( $i = 0; $i < count($transaction); $i++ ): ?>

                                                <div class="col-md-3 my-3">
                                                    <div class="card border-2">
                                                        <div class="card-body">
                                                            <div class="d-flex justify-content-center">
                                                                
                                                                <?php if( !isset($transaction[$i]['gallery']) ): ?>
                                                                    <img src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" class="card-img-top object-fit-cover img-thumbnail" style="width:350px;  height:130px;" alt="image_toko"
                                                                <?php endif; ?>
                                                                <img src="<?php echo e($transaction[$i]['gallery'][0]); ?>" class="card-img-top object-fit-cover img-thumbnail" style="width:350px;  height:130px;" alt="image_toko">
                                                            </div>
                                                            <div class="title text-center fw-semibold my-2" id="Merchant_name"><?php echo e($transaction[$i]['merchant_name']); ?></div>

                                                            <div class="rate">
                                                                <div class="container">
                                                                    <div class="row">
                                                                        <div class="col-md-6">
                                                                            <div class="d-flex justify-content-center align-items-center">
                                                                                <div class="star d-block justify-content-center align-items-center">
                                                                                    <div class="star text-center">
                                                                                        <i class="fa-solid fa-star" style="color: #ffa800;"></i>
                                                                                    </div>
                                                                                    <div class="star-desc text-center">
                                                                                        <span id="rate"><?php echo e($transaction[$i]['rating']); ?>/5 <br> <sub class="fw-semibold">Reviews</sub></span>
                                                                                    </div>
                                                                                </div>

                                                                            </div>
                                                                        </div>

                                                                        <div class="col-md-6">
                                                                            <div class="d-flex justify-content-center align-items-center">
                                                                                <div class="distance d-block justify-content-center align-items-center mt-3 m-md-0">
                                                                                    <div class="distance text-center">
                                                                                        <i class="fa-solid fa-map-location-dot" style="color: #ffa800;"></i>
                                                                                    </div>
                                                                                    <div class="star-desc text-center">
                                                                                        <span id="distance"><?php echo e($transaction[$i]['jarak']); ?><br><sub class="fw-semibold">From your location</sub> </span>
                                                                                    </div>
                                                                                </div>
                                                                            </div>
                                                                        </div>

                                                                    </div>

                                                                    <div class="d-flex justify-content-center align-items-center my-3 mx-auto">
                                                                        <a href="<?php echo e(route('detail-merchant', ['id'=> $transaction[$i]['id']])); ?>" class="btn btn-custome btn-sm" id="booking"><?php echo e(__("Book this Service")); ?></a>
                                                                    </div>

                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endfor; ?>
                                        <?php else: ?>
                                            
                                            <div class="alert alert-secondary text-center fade show" role="alert">
                                                <strong><?php echo e(__('No Data Found!')); ?>

                                            </div>
                                        <?php endif; ?>
                                </div>

                                
                                <div class="row justify-content-center align-items-center">
                                    <div class="col-md-12">
                                        <div class="d-flex justify-content-center align-items-center">
                                            <?php echo e($transaction->links()); ?>

                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>

            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/customer/search.blade.php ENDPATH**/ ?>