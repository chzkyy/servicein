<?php $__env->startSection('title', 'Password Succes'); ?>
<?php $__env->startSection('content'); ?>
<section class="vh-100">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-5 px-0 d-none d-sm-block">
                
                <div class="d-flex align-item-center">
                    <div class="col-12">
                        <div class="d-flex justify-content-start">
                            <div class="logo">
                                <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo" class="logo-img mx-5 mt-4">
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="w-100 vh-100 c-img-login"></div>
                
                <div class="d-flex align-item-center">
                    <div class="col-12">
                        <div class="d-flex justify-content-center">
                            <div class="qoute"></div>
                            <div class="text">
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. </p>
                            </div>
                            <div class="creator blockquote-footer mt-4">
                                Vincent Obi
                            </div>
                            <div class="vector"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-7 text-black">
                <div class="d-flex align-item-center px-5 mt-2 pt-4 mb-3 pb-3">
                    <div class="col-12">
                        <div class="d-flex justify-content-end">
                            <div class="create-account">
                                <span class="text-create-account txt-secondary"> <?php echo e(__('Already have an account?')); ?></span>
                                <a href="<?php echo e(route('login')); ?>" class="text-create-account-link txt-primary fw-semibold">Sign In</a>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="d-flex align-items-center px-5 ms-xl-3 mt-4 pt-3">
                    <div class="row">
                        <span class="text-login"><?php echo e(__('Join Us!')); ?></span>
                        <span class="desc-login text-wrap col-md-6"><?php echo e(__('Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor!')); ?></span>
                    </div>
                </div>
                <div class="d-flex align-items-center px-5 ms-xl-4 mt-4 pt-4 pt-xl-0 mt-xl-n5">
                    <div class="col-md-8">

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein_beta\resources\views/confirmation/password-succes.blade.php ENDPATH**/ ?>