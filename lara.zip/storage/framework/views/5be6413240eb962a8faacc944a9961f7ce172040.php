<?php $__env->startSection('title'); ?>
    <?php echo e(__('Notification Center')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="min-vh-100 mt-5 pt-5">
        <div class="container-fluid">
            <div class="container">
                <div class="col-md-12">
                    <div class="container">

                        <div class="row">
                            <div class="col-md-12">
                                <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link text-decoration-none text-black fw-bold"><i class="fas fa-arrow-left"></i> Back</a>
                            </div>
                        </div>

                        <div class="title mt-4">
                            <h2 class="fw-bold txt-black"><?php echo e(__('Notification Center')); ?></h2>
                        </div>

                        <div class="notif-list my-3">
                            
                            <div class="d-flex justify-content-center align-content-center">
                                <div class="col-md-12">
                                    <?php if(session('success')): ?>
                                        <div class="alert alert-success alert-dismissible fade show" role="alert">
                                            <strong><?php echo e(__('Success')); ?>!</strong> <?php echo e(session('success')); ?>

                                            <button type="button" class="btn-close" data-bs-dismiss="alert"
                                                aria-label="Close"></button>
                                        </div>
                                    <?php endif; ?>

                                    <?php if($notif->isEmpty()): ?>
                                        <div class="alert alert-secondary alert-dismissible text-center fade show"
                                            role="alert">
                                            <strong></strong> <?php echo e(__('No data found.')); ?>

                                        </div>
                                    <?php else: ?>
                                        <?php $__currentLoopData = $notif; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            
                                            <?php if($n->status == 0): ?>
                                                <div
                                                    class="card my-2 border rounded rounded-4 text-bg-secondary bg-secondary notif-bg" id="read_notif">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-12 d-flex align-items-center">
                                                                <div class="row">
                                                                    <p class="fw-semibold"><?php echo e($n->title); ?></p>
                                                                    <hr>
                                                                    <span><?php echo e($n->content); ?></span>
                                                                    <input type="hidden" name="notif_id" value="<?php echo e($n->id); ?>">
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <div class="card my-2 border rounded rounded-4">
                                                    <div class="card-body">
                                                        <div class="row">
                                                            <div class="col-md-12 d-flex align-items-center">
                                                                <div class="row">
                                                                    <p class="fw-semibold"><?php echo e($n->title); ?></p>
                                                                    <hr>
                                                                    <span><?php echo e($n->content); ?></span>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            <?php endif; ?>

                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        <div class="row">
                                            <div class="col-md-12 float-right">
                                                <?php echo e($notif->links()); ?>

                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>

                    </div>

                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('additional-script'); ?>
    <script>
        // read notification
        $(document).on('click', '#read_notif', function() {
            var id = $(this).find('input[name="notif_id"]').val();


            $.ajax({
                url: "<?php echo e(route('read-notification')); ?>",
                type: "POST",
                data: {
                    _token: '<?php echo e(csrf_token()); ?>',
                    id: id,
                },
                success: function(data) {
                    // refresh the page
                    location.reload();

                },
                error: function(err) {
                    // console.log(err);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/notifications/index.blade.php ENDPATH**/ ?>