<?php $__env->startSection('title'); ?>
    <?php echo e(__('Login')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section class="min-vh-100">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-5 px-0 d-none d-sm-block">
                    
                    <div class="d-flex align-item-center">
                        <div class="col-12">
                            <div class="d-flex justify-content-start">
                                <div class="logo">
                                    <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo" class="logo-img mx-5 mt-4">
                                </div>
                            </div>
                        </div>
                    </div>

                    
                    <div class="w-100 min-vh-100 c-img-login"></div>

                    
                    <div class="d-flex align-item-center">
                        <div class="col-12">
                            <div class="d-flex justify-content-center">
                                <div class="qoute"></div>
                                <div class="text mt-4">
                                    <p><?php echo e(__("We understand the importance of your laptops and the impact it has on your daily life, which is why we offer fast and reliable services such as repairs, upgrades, and maintenance. Our goal is to provide you with exceptional service that exceeds your expectations.")); ?></p>
                                </div>
                                <div class="vector"></div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-md-7 text-black">
                    <div class="d-flex align-item-center px-5 mt-2 pt-4">
                        <div class="col-12">
                            <div class="d-none d-sm-flex justify-content-end">
                                <div class="create-account">
                                    <span class="text-create-account txt-secondary"> <?php echo e(__('New to Service.in?')); ?></span>
                                    <a href="<?php echo e(route('register')); ?>" class="text-create-account-link txt-primary fw-semibold">Sign Up</a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-flex d-md-none align-items-center justify-content-center py-5 mb-4 pb-4">
                        <img src="<?php echo e(url('assets/img/Logo2.png')); ?>" alt="logo" class="logo-img">
                    </div>

                    <div class="d-flex align-items-center px-5 ms-xl-3 mt-4 pt-3">
                        <div class="row">
                            <span class="text-login"><?php echo e(__('Login')); ?></span>
                            <span class="desc-login"><?php echo e(__('Input your account credential here!')); ?></span>
                        </div>
                    </div>

                    <div class="d-flex align-items-center px-5 ms-xl-4 mt-4 pt-md-4 pt-xl-0 mt-xl-n5">
                        <div class="col-md-8">
                            <form action="<?php echo e(route('login')); ?>" method="post">
                                <?php echo csrf_field(); ?>
                                <div class="form-group">
                                    <label for="username" class="form-label"><?php echo e(__('Email or Username')); ?></label>
                                    <input type="text"
                                        class="form-control <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-lg"
                                        id="username" name="username" value="<?php echo e(old('username')); ?>"
                                        placeholder="Enter Email or Username" required autocomplete="username" autofocus />
                                </div>

                                <div class="form-group mt-2">
                                    <label class="form-label"><?php echo e(__('Password')); ?></label>
                                    <div class="input-group">
                                        <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-lg input-group"
                                        id="password" name="password" required autocomplete="current-password"
                                        placeholder="Enter your password" />
                                        <div class="input-group-append input-group-text" onclick="password()">
                                            <i class="far fa-eye" id="eye"></i>
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group mt-2 remember-me">
                                    <input class="form-check-input checkbox" type="checkbox" name="remember" id="remember" <?php echo e(old('remember') ? 'checked' : ''); ?>>
                                    <label for="remember" class="checkbox-label txt-primary"><?php echo e(__('Remember me on this computer')); ?></label>
                                </div>

                                <div class="form-group mt-3">
                                    <button type="submit"
                                        class="col-12 btn btn-custome btn-lg btn-block"><?php echo e(__('Login')); ?></button>
                                </div>

                                <div class="form-group mt-4">
                                    <a href="<?php echo e(route('redirect')); ?>"
                                        class="col-12 btn btn-with-google btn-lg btn-block btn-google">
                                        <img src="<?php echo e(url('assets/img/icons_google.png')); ?>" alt="google"
                                            class="google-icon">
                                        Login with Google
                                    </a>

                                    
                                    <div class="forgot-password mt-3">
                                        <?php if(Route::has('password.request')): ?>
                                            <a class="btn btn-link text-center d-block forgot-password-link"
                                                href="<?php echo e(route('password.request')); ?>">
                                                <?php echo e(__('Forgot Password?')); ?>

                                            </a>
                                        <?php endif; ?>
                                    </div>


                                    <div class="create-account d-block d-md-none text-center mt-3">
                                        <span class="text-create-account txt-secondary"> <?php echo e(__('New to Service.in?')); ?></span>
                                        <a href="<?php echo e(route('register')); ?>" class="text-create-account-link txt-primary fw-semibold">Sign Up</a>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/auth/login.blade.php ENDPATH**/ ?>