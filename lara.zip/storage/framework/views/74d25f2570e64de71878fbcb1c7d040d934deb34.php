
<ul class="navbar-nav sidebar-bg sidebar sidebar-dark accordion" id="accordionSidebar">

    
    <a class="sidebar-brand d-flex align-items-center justify-content-center" href="<?php echo e(route('home')); ?>">
        <div class="sidebar-brand-text mx-3">
            <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo">
        </div>
    </a>

    
    <hr class="sidebar-divider my-0">

    
    <li class="nav-item active">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-tachometer-alt"></i>
            <span><?php echo e(__("Dashboard")); ?></span></a>
    </li>

    
    

    
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('profile.admin')); ?>">
            <i class="fas fa-fw fa-user"></i>
            <span><?php echo e(__("Profile")); ?></span></a>
    </li>

    

    
    <li class="nav-item">
        <a class="nav-link" href="<?php echo e(route('home')); ?>">
            <i class="fas fa-fw fa-file-invoice"></i>
            <span><?php echo e(__("Bill")); ?></span></a>
    </li>
</ul>

<?php /**PATH C:\laragon\www\servicein\resources\views/includes/adminDashboard/sidebar.blade.php ENDPATH**/ ?>