<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Servicein">
    <meta name="author" content="Servicein">

    <title><?php echo e(__("Merchant - Dashboard")); ?></title>
    <?php echo $__env->make('includes.adminDashboard.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body id="page-top">

    
    <div id="wrapper">

        <?php echo $__env->make('includes.adminDashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div id="content-wrapper" class="d-flex flex-column">

            
            <div id="content">
                
                <nav class="navbar navbar-expand navbar-bg bg-white topbar mb-4 static-top shadow">
                    
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>
                    <?php echo $__env->make('includes.adminDashboard.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                
                <div class="container-fluid">

                    
                    <div class="d-sm-flex align-items-center justify-content-between mb-4">
                        <h1 class="h3 mb-0 text-gray-800">Dashboard</h1>
                    </div>

                    
                    <div class="row">

                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card bg-primary text-white shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="title text-center"><?php echo e(__('Booked')); ?></div>
                                    <h3 class="count_booked text-center font-weight-bold"><?php echo e($status_booked); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card bg-warning text-white shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="title text-center"><?php echo e(__('On Progress')); ?></div>
                                    <h3 class="count_booked text-center font-weight-bold"><?php echo e($status_process); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card bg-success text-white shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="title text-center"><?php echo e(__('Done')); ?></div>
                                    <h3 class="count_booked text-center font-weight-bold"><?php echo e($status_done); ?></h3>
                                </div>
                            </div>
                        </div>
                        <div class="col-xl-3 col-md-6 mb-4">
                            <div class="card bg-danger text-white shadow h-100 py-2">
                                <div class="card-body">
                                    <div class="title text-center"><?php echo e(__('Cancelled')); ?></div>
                                    <h3 class="count_booked text-center font-weight-bold"><?php echo e($status_cancel); ?></h3>
                                </div>
                            </div>
                        </div>

                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                </div>
                

            </div>
            

            <?php echo $__env->make('includes.adminDashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        

    </div>
    

    
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php echo $__env->make('includes.adminDashboard.modal.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('includes.adminDashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additional-script'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\servicein\resources\views/layouts/adminDashboard.blade.php ENDPATH**/ ?>