
<nav class="navbar fixed-top navbar-expand-lg navbar-bg">
    <div class="container-fluid">
        <a class="navbar-brand mx-2" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(url('assets/img/Logo.png')); ?>" alt="logo">
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown"
            aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav col-md-12 d-flex justify-content-end">

                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item col-md-6 my-4 my-md-1 mx-auto mb-4 mb-md-0">

                        <div class="custom-search">
                            <form action="<?php echo e(route('search-merchant')); ?>" method="get" id="search_merchant">
                                <input type="text" class="custom-search-input" id="search" name="search" placeholder="Search" value="<?php echo e(request('search')); ?>">
                                <input type="hidden" name="origin" id="origin">
                                <button class="custom-search-botton" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </form>
                        </div>
                    </li>
                <?php elseif( Auth::user()->role != 'Admin' ): ?>
                    <li class="nav-item col-md-6 my-4 my-md-1 mx-auto mb-4 mb-md-0">
                        <div class="custom-search">
                            <form action="<?php echo e(route('search-merchant')); ?>" method="get" id="search_merchant">

                                <input type="text" class="custom-search-input" id="search" name="search" placeholder="Search" value="<?php echo e(request('search')); ?>">
                                <input type="hidden" name="origin" id="origin">
                                <button class="custom-search-botton" type="submit"><i class="fa fa-search" aria-hidden="true"></i></button>
                            </form>
                        </div>
                    </li>

                <?php endif; ?>

                
                
                <li class="nav-item dropdown my-auto mx-1">

                    
                    <a class="nav-link" id="notificationDropdown" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                        
                        <span class="d-none badge bg-danger position-absolute top-0 start-50 badge-counter badge-pill" id="notif_count"></span>
                        <i class="fas fa-bell fa-fw" style="color: #fff"></i>
                        
                        <span class="d-md-none position-absolute badge bg-danger ms-2 fw-semibold text-white start-0 top-0 badge-pill badge-counter" id="notif_mobile"></span>
                        <span class="d-md-none ms-2 fw-semibold text-white">Notification</span>
                    </a>


                    <ul class="dropdown-menu dropdown-menu-end mt-3 dropdown-menu-right shadow animated--grow-in" aria-labelledby="notificationDropdown">
                        <li><h6 class="dropdown-header text-white border border-1 border-dark rounded bg-warning fw-semibold">NOTIFICATION CENTER</h6></li>

                        <li id="notif_list" class="text-center small text-gray-500"></li>
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="text-center small text-gray-500"><?php echo e(__("No Notification")); ?></li>
                        <?php else: ?>
                            <li>
                                <a class="dropdown-item text-center small mb-n3 text-gray-600" href="<?php echo e(route('notification')); ?>">Show All Notification</a>
                            </li>
                        <?php endif; ?>
                        
                    </ul>
                </li>

                
                <li class="nav-item my-auto mx-1">
                    <a class="nav-link" id="messagesDropdown" href="<?php echo e(route('chat')); ?>" >
                        
                        <span class="d-none badge bg-danger position-absolute top-0 my-3 ms-2 badge-counter badge-pill" id="chat_dstp"></span>
                        <i class="fas fa-envelope fa-fw" style="color: #fff"></i>
                        
                        <span class="d-md-none position-absolute badge bg-danger ms-2 fw-semibold text-white start-0 top-0 badge-pill badge-counter" id="chat_mobile"></span>
                        <span class="d-md-none ms-2 fw-semibold text-white">Messages</span>
                    </a>
                </li>

                <div class="vr mx-1 my-auto d-none d-md-block"></div>

                <?php if(auth()->guard()->guest()): ?>
                    <li class="nav-item dropdown">
                        <a href="<?php echo e(route('login')); ?>" class="nav-link">
                            
                            <img src="<?php echo e(url('assets/img/Avatar.png')); ?>" alt="Avatar" class="img-fluid">
                            <span class="mx-2 fw-semibold text-white">Login / Sign Up</span>
                        </a>
                    </li>
                <?php else: ?>
                    <li class="nav-item dropdown ">
                        <a class="nav-link" href="#" role="button" data-bs-toggle="dropdown"
                            aria-expanded="false">
                            <img src="<?php echo e(url('assets/img/Avatar.png')); ?>" alt="Avatar" class="img-fluid">
                            <span class="mx-2 fw-semibold text-white"><?php echo e(Auth::user()->username); ?></span>
                        </a>
                        <ul class="dropdown-menu mt-3 dropdown-menu-end">
                            <li>
                                <?php if( Auth::user()->role == 'Admin' ): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('profile.admin')); ?>">Profile</a>
                                <?php else: ?>
                                    <a class="dropdown-item" href="<?php echo e(route('profile')); ?>">Profile</a>
                                <?php endif; ?>
                            </li>
                            <li>
                                <?php if( Auth::user()->role == 'User' ): ?>
                                    <a class="dropdown-item" href="<?php echo e(route('show-transaction')); ?>">Transaction List</a>
                                <?php endif; ?>
                            </li>
                            <hr>
                            <li>
                                <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                    onclick="event.preventDefault();
                                                    document.getElementById('logout-form').submit();">
                                    <?php echo e(__('Logout')); ?>

                                </a>

                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                    <?php echo csrf_field(); ?>
                                </form>
                            </li>
                        </ul>
                    </li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
<?php /**PATH C:\laragon\www\servicein\resources\views/includes/dashboard/navbar.blade.php ENDPATH**/ ?>