<?php $__env->startSection('title'); ?>
    <?php echo e(__('Device List')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="vh-100 mt-5 pt-md-5">
    <div class="container-fluid">
        <div class="container">
            <div class="col-md-12">
                <div class="container">
                    <div class="button_top my-5 pt-3">
                        <div class="d-flex justify-content-between">
                            
                            <a data-bs-toggle="modal" data-bs-target="#addDevice" class="btn btn-custome fw-bold"><?php echo e(__('Add New')); ?></a>

                            
                            <div class="custom-search">
                                <form action="" method="POST" id="searchDeviceList">
                                    <input type="text" class="custom-search-input" id="searchDevice" placeholder="Search" onkeyup="filter_SearchDevice()">
                                    
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="device-list">
                        
                        <div class="d-flex justify-content-center align-content-center">
                            <div class="col-md-12">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <strong><?php echo e(__('Success')); ?>!</strong> <?php echo e(session('success')); ?>

                                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                                    </div>
                                <?php endif; ?>

                                
                                <?php if( $device->isEmpty() ): ?>
                                    <div class="alert alert-secondary alert-dismissible text-center fade show" role="alert">
                                        <strong></strong> <?php echo e(__('No devices found.')); ?>

                                    </div>
                                <?php else: ?>
                                    <?php $__currentLoopData = $device; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="card my-2 device">
                                            <div class="card-body">
                                                <div class="row">
                                                    <div class="col-md-2 d-flex align-items-center">
                                                        <?php if($d->device_picture == null): ?>
                                                            <img src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="device_images" class="img-thumbnail img-fluid" style="width: 150px; height: auto;">
                                                        <?php else: ?>
                                                            <img src="<?php echo e($d->device_picture); ?>" alt="device_images" class="img-thumbnail img-fluid" style="width: 150px; height: auto;">
                                                        <?php endif; ?>
                                                    </div>
                                                    <div class="col-md-8 d-flex align-items-center">
                                                        <div class="row">
                                                            <p class="fw-semibold"><?php echo e($d->device_name); ?></p>
                                                            <span><?php echo e($d->serial_number); ?></span>
                                                        </div>
                                                    </div>

                                                    <div class="col-md-2 d-flex align-items-center">
                                                        <div class="row">
                                                            <a data-bs-toggle="modal" data-bs-target="#editDevice" class="btn btn-custome my-2 fw-bold"><?php echo e(__('Edit')); ?></a>
                                                            

                                                            <button class="btn btn-danger my-2" onclick="remove_Device(<?php echo e($d->id); ?>)"><?php echo e(__("Delete")); ?></button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        
                                        <div class="modal fade" id="editDevice" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-scrollable modal-lg modal-dialog-centered">
                                                <div class="modal-content rounded-1 border-0 text-black">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Add Device')); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>

                                                    <div class="modal-body">
                                                        <form action="<?php echo e(route('edit-device')); ?>" method="POST" id="form_EditDevice" enctype="multipart/form-data">
                                                            <?php echo csrf_field(); ?>
                                                            <div class="row">
                                                                <div class="col-md-6">
                                                                    <div class="form-group mb-2">
                                                                        <label for="edit_device_name" class="form-label"><?php echo e(__('Device Name')); ?></label>
                                                                        <input type="text" class="form-control <?php $__errorArgs = ['edit_device_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="edit_device_name" id="edit_device_name" placeholder="Input Your Device Name" value="<?php echo e($d->device_name); ?>" required autofocus>
                                                                    </div>

                                                                    <div class="form-group mb-2">
                                                                        <label for="edit_type" class="form-label"><?php echo e(__('Device Type')); ?></label>
                                                                        <input type="text" class="form-control <?php $__errorArgs = ['edit_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="edit_type" id="edit_type" placeholder="Input Your Device Type" value="<?php echo e($d->type); ?>" required autofocus>
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-6">
                                                                    <div class="form-group mb-2">
                                                                        <label for="edit_brand" class="form-label"><?php echo e(__('Device Brand')); ?></label>
                                                                        <input type="text" class="form-control <?php $__errorArgs = ['edit_brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="edit_brand" id="edit_brand" placeholder="Input Your Device Brand" value="<?php echo e($d->brand); ?>" required autofocus>
                                                                    </div>

                                                                    <div class="form-group mb-2">
                                                                        <label for="edit_serial_number" class="form-label"><?php echo e(__('Device Serial Number')); ?></label>
                                                                        <input type="text" class="form-control <?php $__errorArgs = ['edit_serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="edit_serial_number" id="edit_serial_number" placeholder="Input Your Device Serial Number" value="<?php echo e($d->serial_number); ?>" required autofocus>
                                                                    </div>
                                                                </div>

                                                                <div class="col-md-12">
                                                                    <div class="form-group">
                                                                        <label class="form-label"><?php echo e(__("Device Picture")); ?></label>
                                                                        <img class="img-fluid img-thumbnail img-preview-edit my-4">
                                                                        <input type="file" class="d-block form-control <?php $__errorArgs = ['edit_device_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="edit_device_image" name="edit_device_image" onchange="preview_EditDevice()" accept="image/*">
                                                                        <small class="form-text text-muted">Maximum size 2MB</small>
                                                                    </div>
                                                                </div>

                                                                <hr class="mt-5">
                                                                <div class="col-md-12">
                                                                    <div class="d-flex justify-content-center align-content-center">
                                                                        <input type="hidden" name="device" id="device" value="<?php echo e($d->id); ?>">
                                                                        <button type="submit" class="btn btn-custome col-md-2 mx-auto" id="submit_EditDevices">Save</button>
                                                                    </div>
                                                                </div>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    <div class="row">
                                        <div class="col-md-12 float-right">
                                            <?php echo e($device->links()); ?>

                                        </div>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>

            </div>
        </div>
    </div>
</section>


<div class="modal fade" id="addDevice" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg modal-dialog-centered">
        <div class="modal-content rounded-1 border-0 text-black">
            <div class="modal-header">
                <h5 class="modal-title" id="staticBackdropLabel"><?php echo e(__('Add Device')); ?></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>

            <div class="modal-body">
                <form action="<?php echo e(route('add-device')); ?>" method="POST" id="form_addDevice" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="device_name" class="form-label"><?php echo e(__('Device Name')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['device_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="device_name" id="device_name" placeholder="Input Your Device Name" required autofocus>
                            </div>

                            <div class="form-group mb-2">
                                <label for="type" class="form-label"><?php echo e(__('Device Type')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="type" id="type" placeholder="Input Your Device Type" required autofocus>
                            </div>
                        </div>

                        <div class="col-md-6">
                            <div class="form-group mb-2">
                                <label for="brand" class="form-label"><?php echo e(__('Device Brand')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['brand'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="brand" id="brand" placeholder="Input Your Device Brand" required autofocus>
                            </div>

                            <div class="form-group mb-2">
                                <label for="serial_number" class="form-label"><?php echo e(__('Device Serial Number')); ?></label>
                                <input type="text" class="form-control <?php $__errorArgs = ['serial_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> form-control-md" name="serial_number" id="serial_number" placeholder="Input Your Device Serial Number" required autofocus>
                            </div>
                        </div>

                        <div class="col-md-12">
                            <div class="form-group">
                                <label class="form-label"><?php echo e(__("Device Picture")); ?></label>
                                <img class="img-fluid img-thumbnail img-preview my-4">
                                <input type="file" class="d-block form-control <?php $__errorArgs = ['device_picture'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="device_image" name="device_image" onchange="preview_AddDevice()" accept="image/*">
                                <small class="form-text text-muted">Maximum size 2MB</small>
                            </div>
                        </div>

                        <hr class="mt-5">
                        <div class="col-md-12">
                            <div class="d-flex justify-content-center align-content-center">
                                <button type="submit" class="btn btn-custome col-md-2 mx-auto" id="submit_addDevices">Add Device</button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('additional-script'); ?>
    <script>

        function preview_AddDevice() {
            const avatar = document.querySelector('#device_image');
            const imgPreview = document.querySelector('.img-preview');

            imgPreview.style.display = 'block';

            const OFReader = new FileReader();
            OFReader.readAsDataURL(avatar.files[0]);

            OFReader.onload = function(OFREvent) {
                imgPreview.src = OFREvent.target.result;
            }
        }

        function preview_EditDevice() {
            const avatar = document.querySelector('#edit_device_image');
            const imgPreview = document.querySelector('.img-preview-edit');

            imgPreview.style.display = 'block';

            const OFReader = new FileReader();
            OFReader.readAsDataURL(avatar.files[0]);

            OFReader.onload = function(OFREvent) {
                imgPreview.src = OFREvent.target.result;
            }
        }

        // create filter search for displaying card information
        function filter_SearchDevice() {
            const search = document.querySelector('#searchDevice');
            search.focus();

            search.addEventListener('keyup', function() {
                if (this.value.length > 0) {
                    const result = document.querySelectorAll('.device');

                    for (let i = 0; i < result.length; i++) {
                        if (result[i].textContent.toLowerCase().indexOf(this.value.toLowerCase()) > -1) {
                            result[i].classList.remove('d-none');
                        } else {
                            result[i].classList.add('d-none');
                        }
                    }
                }
            });

            // if click enter button, then return false
            search.addEventListener('keydown', function(e) {
                if (e.keyCode === 13) {
                    e.preventDefault();
                    return false;
                }
            });

            return false;
        }

        // remove device with sweetalert
        function remove_Device(id) {
            Swal.fire({
                text: 'Are you sure want to delete this data?',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3c10fe5',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $.ajax({
                        url: '/device/remove/' + id,
                        type: 'GET',
                        success: function() {
                            Swal.fire(
                                'Deleted!',
                                'Your device has been deleted.',
                                'success'
                            ).then((result) => {
                                location.reload();
                            });
                        }
                    });
                }
            })
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/customer/profile/addDevice.blade.php ENDPATH**/ ?>