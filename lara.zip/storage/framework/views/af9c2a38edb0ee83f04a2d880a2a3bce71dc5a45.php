<?php $__env->startSection('title'); ?>
    <?php echo e(__('Merchant - Detail Transaction')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class="min-vh-100">
    <div class="container-fluid">
        <div class="container">
            <div class="col-md-12">
                <div class="container">

                    <div class="row">
                        <div class="col-md-12">
                            <a href="<?php echo e(url()->previous()); ?>" class="btn btn-link text-decoration-none text-black fw-bold"><i class="fas fa-arrow-left"></i> Back</a>
                        </div>
                    </div>

                    <div class="transaction-detail mb-2">
                        <div class="row">
                            <div class="card my-2 transaction mb-2 border border-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-2 d-flex align-items-center">
                                            <?php if($transaction->device_picture == null): ?>
                                                <img src="<?php echo e(asset('assets/img/no-image.jpg')); ?>" alt="device_images" class="img-thumbnail img-fluid" style="width: 150px; height: auto;">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset($transaction->device_picture)); ?>" alt="device_images" class="img-thumbnail img-fluid" style="width: 150px; height: auto;">
                                            <?php endif; ?>
                                        </div>
                                        <div class="col-md-8 d-flex align-items-center">
                                            <div class="row">
                                                <p class="fw-semibold"></p>
                                                <span>Device : <?php echo e($transaction->device_name); ?></span>
                                                <div>
                                                    <?php echo e(__("Status :")); ?>

                                                    <?php if($transaction->status == 'BOOKED'): ?>
                                                        <span class="badge badge-primary"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'DONE'): ?>
                                                        <span class="badge badge-success"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'CANCELLED'): ?>
                                                        <span class="badge badge-danger"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'ON PROGRESS'): ?>
                                                        <span class="badge badge-dark"><?php echo e($transaction->status); ?></span>
                                                    <?php elseif($transaction->status == 'ON PROGRESS - Need Confirmation'): ?>
                                                        
                                                        <?php
                                                            $status = explode(' - ', $transaction->status);
                                                        ?>
                                                        <span class="badge badge-dark"><?php echo e($status[0]); ?></span><?php echo e(__(" - ")); ?><span class="badge badge-warning"><?php echo e($status[1]); ?></span>
                                                    <?php elseif($transaction->status == 'ON COMPLAINT'): ?>
                                                        <span class="badge badge-info"><?php echo e($transaction->status); ?></span>
                                                    <?php endif; ?>
                                                </div>
                                                <span>Transaction ID : <?php echo e($transaction->no_transaction); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="detail">
                        <div class="row">
                            <div class="card my-2 detail mb-2 border border-2">
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-md-12 txt-gold fs-5">
                                            <?php echo e(__("Customer Name :")); ?>

                                        </div>

                                        <div class="col-md-12 txt-gold fs-5 fw-bold">
                                            <?php echo e(ucwords($transaction->fullname)); ?>

                                        </div>

                                        <div class="col-md-12 my-4">
                                            
                                            <?php if($transaction->status == 'ON PROGRESS'): ?>
                                                <button type="button" class="btn btn-custome btn-sm" data-bs-toggle="modal" data-bs-target="#createConfirmation">
                                                    <?php echo e(__('Create Confirmation')); ?>

                                                </button>
                                            <?php endif; ?>
                                        </div>

                                        
                                        <div class="col-md-12">
                                            <div class="row">
                                                <div class="col-md-3 my-4">
                                                    
                                                    <div class="fw-semibold txt-gold"><?php echo e(__('Device Owner')); ?></div>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Full name')); ?></div>
                                                        <div><?php echo e(ucwords($transaction->fullname)); ?></div>
                                                    </div>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Gender')); ?></div>
                                                        <div><?php echo e(ucwords($transaction->gender)); ?></div>
                                                    </div>
                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Birth Date')); ?></div>
                                                        


                                                        <div>
                                                            <?php if($transaction->bod == null): ?>
                                                                <?php echo e(__('-')); ?>

                                                            <?php else: ?>
                                                                <?php echo e(date("d M Y", strtotime($transaction->bod))); ?>

                                                            <?php endif; ?>
                                                        </div>
                                                    </div>
                                                </div>

                                                <div class="col-md-3 my-4">
                                                    <p class="fw-semibold txt-gold"><?php echo e(__('Booking Detail')); ?></p>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Time')); ?></div>
                                                        <div><?php echo e(date("H:i", strtotime($transaction->booking_time)).__(' WIB')); ?></div>

                                                    </div>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__('Date')); ?></div>
                                                        <div><?php echo e(date("l, d m Y", strtotime($transaction->booking_date))); ?></div>
                                                    </div>
                                                </div>

                                                <div class="col-md-6 my-4">
                                                    <p class="fw-semibold txt-gold"><?php echo e(__("Description")); ?></p>
                                                        
                                                    <?php if($transaction->status == 'BOOKED'): ?>
                                                        <div class="form-group">
                                                            <textarea name="merchant_note" class="form-control  " id="merchant_note" cols="25" rows="3"></textarea>
                                                        </div>
                                                    <?php elseif($transaction->status == 'DONE'): ?>

                                                        <div class="row my-2">
                                                            <div class="fw-semibold"><?php echo e(__("Merchant Note")); ?></div>
                                                            <?php if($transaction->merchant_note == null): ?>
                                                                <div><?php echo e(__('-')); ?></div>
                                                            <?php else: ?>
                                                                <div><?php echo e($transaction->merchant_note); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php elseif($transaction->status == 'CANCELLED'): ?>
                                                        <div class="row my-2">
                                                            <div class="fw-semibold"><?php echo e(__("Merchant Note")); ?></div>
                                                            <?php if($transaction->merchant_note == null): ?>
                                                                <div><?php echo e(__('-')); ?></div>
                                                            <?php else: ?>
                                                                <div><?php echo e($transaction->merchant_note); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php elseif($transaction->status == 'ON PROGRESS'): ?>
                                                        <div class="row my-2">
                                                            <div class="fw-semibold"><?php echo e(__("Merchant Note")); ?></div>
                                                            <?php if($transaction->merchant_note == null): ?>
                                                                <div><?php echo e(__('-')); ?></div>
                                                            <?php else: ?>
                                                                <div><?php echo e($transaction->merchant_note); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php elseif($transaction->status == 'ON PROGRESS - Need Confirmation'): ?>
                                                        <div class="row my-2">
                                                            <div class="fw-semibold"><?php echo e(__("Merchant Note")); ?></div>
                                                            <?php if($transaction->merchant_note == null): ?>
                                                                <div><?php echo e(__('-')); ?></div>
                                                            <?php else: ?>
                                                                <div><?php echo e($transaction->merchant_note); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php elseif($transaction->status == 'ON COMPLAINT'): ?>
                                                    <div class="row my-2">
                                                            <div class="fw-semibold"><?php echo e(__("Merchant Note")); ?></div>
                                                            <?php if($transaction->merchant_note == null): ?>
                                                                <div><?php echo e(__('-')); ?></div>
                                                            <?php else: ?>
                                                                <div><?php echo e($transaction->merchant_note); ?></div>
                                                            <?php endif; ?>
                                                        </div>
                                                    <?php endif; ?>

                                                    <div class="row my-2">
                                                        <div class="fw-semibold"><?php echo e(__("Customer Note")); ?></div>
                                                        <?php if($transaction->user_note == null): ?>
                                                            <div><?php echo e(__('-')); ?></div>
                                                        <?php else: ?>
                                                            <div><?php echo e($transaction->user_note); ?></div>
                                                        <?php endif; ?>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>

                                        <?php if($transaction->status == 'BOOKED'): ?>
                                            <div class="col-md-12">
                                                <div class="row">
                                                    <div class="fw-semibold">Status</div>
                                                    <div class="col-md-2 my-2">
                                                        <select name="status" id="status_select" class="form-control select2">
                                                            <option value=""></option>
                                                            <option value="DONE"><?php echo e(__('Done')); ?></option>
                                                            <option value="ON PROGRESS"><?php echo e(__('On Progress')); ?></option>
                                                            <option value="CANCELLED"><?php echo e(__('Cancle')); ?></option>
                                                        </select>

                                                        <div class="btn-sv my-4">
                                                            <input type="hidden" name="no_transaction" id="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                            <a id="prosess_transaksi" class="btn btn-md rounded rounded-3 col-md-12 btn-custome"><?php echo e(__('Proceed')); ?></a>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php elseif($transaction->status == 'ON PROGRESS'): ?>
                                            <div class="col-md-12">
                                                <div class="btn-sv d-flex justify-content-center align-content-center my-4">
                                                    <input type="hidden" name="no_transaction" id="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                    <input type="hidden" name="status" id="status" value="DONE">

                                                    <a id="transaksi_done" class="btn btn-md rounded rounded-3 col-md-2 btn-custome"><?php echo e(__('Done')); ?></a>
                                                </div>
                                            </div>
                                        <?php elseif($transaction->status == 'ON COMPLAINT'): ?>
                                            <div class="col-md-12">
                                                <div class="btn-sv d-flex justify-content-center align-content-center my-4">
                                                    <input type="hidden" name="no_transaction" id="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                    <input type="hidden" name="status" id="status" value="DONE">

                                                    <a id="done_complaint" class="btn btn-md rounded rounded-3 col-md-2 btn-custome"><?php echo e(__('Done')); ?></a>
                                                </div>
                                            </div>
                                        <?php elseif($transaction->status == 'DONE'): ?>
                                            <?php if($transaction->waranty == null): ?>
                                                
                                                <div class="col-md-12">
                                                    <div class="btn-sv d-flex justify-content-center align-content-center my-4">
                                                        <input type="hidden" name="no_transaction" id="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                        <a id="create_invoice" href="<?php echo e(route('create-invoice', ['id' => $transaction->no_transaction])); ?>" class="btn btn-md rounded rounded-3 col-md-2 btn-custome"><?php echo e(__('Create Invoice')); ?></a>
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                
                                                <div class="col-md-12">
                                                    <div class="btn-sv d-flex justify-content-center align-content-center my-4">
                                                        <input type="hidden" name="no_transaction" id="no_transaction" value="<?php echo e($transaction->no_transaction); ?>">
                                                        <a id="view_invoice" href="<?php echo e(route('view-invoice', ['id' => $transaction->no_transaction])); ?>" class="btn btn-md rounded rounded-3 col-md-2 btn-custome"><?php echo e(__('View Invoice')); ?></a>
                                                    </div>
                                                </div>

                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>
</section>

<?php echo $__env->make('includes.adminDashboard.modal.service-confirmation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('additional-script'); ?>
    <script>
        $('#status_select').select2({
            placeholder: "Select Status",
            thema: "bootstrap-5",
        });

        $('#prosess_transaksi').click(function() {
            var status          = $('#status_select').val();
            var merchant_note   = $('#merchant_note').val();
            var no_transaction  = $('#no_transaction').val();

            if ( status == '' )
            {
                Swal.fire({
                    icon: 'error',
                    title: 'Oops...',
                    text: 'Please select status!',
                });
            } else {
                Swal.fire({
                    title: 'Are you sure?',
                    text: "Do you want to update status for this transaaction?",
                    icon: 'warning',
                    showCancelButton: true,
                    confirmButtonColor: '#e3c10fe5',
                    confirmButtonText: 'Yes, send it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        $('#prosess_transaksi').html('<i class="fa fa-spinner fa-spin"></i> Loading...');
                        $('#prosess_transaksi').addClass('disabled');

                        if ( status == 'DONE' )
                        {
                            $.ajax({
                                url: "<?php echo e(route('update-status-transaction')); ?>",
                                type: "POST",
                                data: {
                                    _token: "<?php echo e(csrf_token()); ?>",
                                    status: status,
                                    merchant_note: merchant_note,
                                    no_transaction: no_transaction,
                                },
                                success: function(response) {
                                    if (response.message == "Success") {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Success',
                                            text: response.message,
                                            showConfirmButton: false,
                                            timer: 1500
                                        }).then(function() {
                                            window.location.href = "<?php echo e(route('create-invoice', ['id' => $transaction->no_transaction])); ?>";
                                        });
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Oops...',
                                            text: response.message,
                                        });
                                    }
                                },
                                error: function(response) {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Oops...',
                                        text: response.message,
                                    });
                                }
                            });
                        } else {
                            $.ajax({
                                url: "<?php echo e(route('update-status-transaction')); ?>",
                                type: "POST",
                                data: {
                                    _token: "<?php echo e(csrf_token()); ?>",
                                    status: status,
                                    merchant_note: merchant_note,
                                    no_transaction: no_transaction,
                                },
                                success: function(response) {
                                    if (response.message == "Success") {
                                        Swal.fire({
                                            icon: 'success',
                                            title: 'Success',
                                            text: response.message,
                                            showConfirmButton: false,
                                            timer: 1500
                                        }).then(function() {
                                            // reload page
                                            location.reload();
                                        });
                                    } else {
                                        Swal.fire({
                                            icon: 'error',
                                            title: 'Oops...',
                                            text: response.message,
                                        });
                                    }
                                },
                                error: function(response) {
                                    Swal.fire({
                                        icon: 'error',
                                        title: 'Oops...',
                                        text: response.message,
                                    });
                                }
                            });
                        }
                    }
                });
            }

        });

        $('#transaksi_done').click(function() {
            var status          = $('#status').val();
            var no_transaction  = $('#no_transaction').val();
            var customer_id     = $('#customer_id').val();

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want done this transaaction?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3c10fe5',
                confirmButtonText: 'Yes, send it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#transaksi_done').html('<i class="fa fa-spinner fa-spin"></i> Loading...');
                    $('#transaksi_done').addClass('disabled');

                    $.ajax({
                        url: "<?php echo e(route('update-status-transaction')); ?>",
                        type: "POST",
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>",
                            status: status,
                            no_transaction: no_transaction,
                        },
                        success: function(response) {
                            if (response.message == "Success") {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: response.message,
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(function() {
                                    window.location.href = "<?php echo e(route('create-invoice', ['id' => $transaction->no_transaction])); ?>";
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: response.message,
                                });
                            }
                        },
                        error: function(response) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: response.message,
                            });
                        }
                    });
                }
            });
        });

        $('#done_complaint').click(function() {
            var status          = $('#status').val();
            var no_transaction  = $('#no_transaction').val();
            var customer_id     = $('#customer_id').val();

            Swal.fire({
                title: 'Are you sure?',
                text: "Do you want done this transaaction?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3c10fe5',
                confirmButtonText: 'Yes, send it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#done_complaint').html('<i class="fa fa-spinner fa-spin"></i> Loading...');
                    $('#done_complaint').addClass('disabled');

                    $.ajax({
                        url: "<?php echo e(route('update-status-transaction')); ?>",
                        type: "POST",
                        data: {
                            "_token": "<?php echo e(csrf_token()); ?>",
                            status: status,
                            no_transaction: no_transaction,
                        },
                        success: function(response) {
                            if (response.message == "Success") {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: response.message,
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(function() {
                                    // reload page
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: response.message,
                                });
                            }
                        },
                        error: function(response) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: response.message,
                            });
                        }
                    });
                }
            });

        });

        $('#submitConfirmation').click(function() {
            var no_transaction          = $('#no_transaction').val();
            var customer_id             = $('#customer_id').val();
            var service_confirmation    = $('#service_confirmation').val();

            Swal.fire({
                title: 'Are you sure?',
                text: "You want to send confirmation to customer?",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#e3c10fe5',
                confirmButtonText: 'Yes, send it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    $('#submitConfirmation').html('<i class="fa fa-spinner fa-spin"></i> Sending...');
                    $('#submitConfirmation').addClass('disabled');
                    $('#close').addClass('disabled');
                    
                    $.ajax({
                        url: "<?php echo e(route('send-confirmation')); ?>",
                        type: "POST",
                        data: {
                            _token: "<?php echo e(csrf_token()); ?>",
                            no_transaction: no_transaction,
                            customer_id: customer_id,
                            service_confirmation: service_confirmation,
                        },
                        success: function(response) {
                            if (response.message == "Success") {
                                Swal.fire({
                                    icon: 'success',
                                    title: 'Success',
                                    text: response.message,
                                    showConfirmButton: false,
                                    timer: 1500
                                }).then(function() {
                                    // reload page
                                    location.reload();
                                });
                            } else {
                                Swal.fire({
                                    icon: 'error',
                                    title: 'Oops...',
                                    text: response.message,
                                });
                            }
                        },
                        error: function(response) {
                            Swal.fire({
                                icon: 'error',
                                title: 'Oops...',
                                text: response.message,
                            });
                        }
                    });
                }
            })
        });

    </script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.profileMerchant', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/adminToko/Transaksi/detail-transaksi.blade.php ENDPATH**/ ?>