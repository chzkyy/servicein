
<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>&copy; Copyright <?php echo e(date("Y")); ?> | Powered by Servicein.</span>
        </div>
    </div>
</footer>

<?php /**PATH C:\laragon\www\servicein\resources\views/includes/adminDashboard/footer.blade.php ENDPATH**/ ?>