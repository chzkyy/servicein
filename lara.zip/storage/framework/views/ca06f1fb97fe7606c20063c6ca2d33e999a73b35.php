<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Servicein">
    <meta name="author" content="Servicein">

    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php echo $__env->make('includes.adminDashboard.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</head>

<body id="page-top">

    
    <div id="wrapper">

        <?php echo $__env->make('includes.adminDashboard.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
        <div id="content-wrapper" class="d-flex flex-column">

            
            <div id="content">
                
                <nav class="navbar navbar-expand navbar-bg bg-white topbar mb-4 static-top shadow">
                    <?php echo $__env->make('includes.adminDashboard.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                
                <div class="container-fluid">
                    <div class="row">
                        <?php echo $__env->yieldContent('content'); ?>
                    </div>

                </div>
                

            </div>
            

            <?php echo $__env->make('includes.adminDashboard.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>
        

    </div>
    

    
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?php echo $__env->make('includes.adminDashboard.modal.logout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('includes.adminDashboard.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('additional-script'); ?>

</body>

</html>
<?php /**PATH C:\laragon\www\servicein\resources\views/layouts/app.blade.php ENDPATH**/ ?>