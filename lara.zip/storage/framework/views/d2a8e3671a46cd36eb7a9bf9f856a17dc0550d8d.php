<?php $__env->startSection('title'); ?>
    <?php echo e(__("Chat")); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<section class=" mt-5">
    <div class="container-fluid">
        <div class="col-md-12">
            <div class="container pt-5">
                
                <div class="row">
                    <div class="col-md-12">
                        <a href="<?php echo e(url()->previous()); ?>" class="text-decoration-none text-dark">
                            <i class="fas fa-arrow-left"></i>
                            <span class="ms-2"><?php echo e(__("Back")); ?></span>
                        </a>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-12">
                        <div class="card border border-1 rounded rounded-3 h-auto" style="border-color: #655503 !important;">
                            
                            <div class="card-header bg-transparent border">
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="row my-3 d-flex align-items-center">
                                            <div class="col-3 col-md-1 profile-img my-auto d-flex justify-content-end align-content-center">
                                                <img src="<?php echo e(url($avatar)); ?>"
                                                    class="img-circle" alt="Profile Image">
                                            </div>
                                            <div class="col-8">
                                                <div class="name fw-semibold">
                                                    <?php echo e(ucwords($name)); ?>

                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="card-body">
                                
                                <div class="card-bubble">
                                    <div class="containerBubble" id='cntrBubble'>
                                    </div>
                                </div>

                                
                                <div class="bg-transparent mt-3">
                                    <div class="input-group">
                                        
                                        <textarea name="" id="chat-text" cols="30" rows="1" class="form-control shadow rounded rounded-2 border-1 border-secondary bg-light small" placeholder="Type a message"></textarea>
                                        <div class="input-group-append">
                                            <button class="btn btn-primary ms-2" type="button">
                                                <i class="fas fa-paperclip"></i>
                                            </button>
                                            <button class="btn btn-primary" id="sendChat" type="button">
                                                <i class="fas fa-paper-plane"></i>
                                            </button>
                                        </div>
                                    </div>
                                </div>
                                <div class="chat">

                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('additional-script'); ?>
    <script>
        $(document).ready(function() {
            $(".containerBubble").animate({ scrollTop: 20000000 }, "slow");

            // panggil ajax setiap 5 detik
            setInterval(function() {
                getChat();
            }, 5000); //5 seconds

            getChat();

            $('#sendChat').click(function() {
                var chat = $('#chat-text').val();
                $.ajax({
                    url: "<?php echo e(route('sendMessageCust')); ?>",
                    type: "POST",
                    data: {
                        _token: "<?php echo e(csrf_token()); ?>",
                        to: "<?php echo e($merchant_id); ?>",
                        from: "<?php echo e(auth()->user()->id); ?>",
                        message: chat
                    },
                    dataType: "json",
                    success: function(data) {
                        $('#chat-text').val('');
                        getChat();
                    }
                })
            });
        });


        function getChat() {
            $.ajax({
                url: "<?php echo e(route('getChatCust')); ?>",
                type: "POST",
                data: {
                    _token: "<?php echo e(csrf_token()); ?>",
                    merchant_id: "<?php echo e($merchant_id); ?>"
                },
                dataType: "json",
                success: function(data) {
                    //console.log(data);
                    var html = '';
                    $.each(data, function(index, value) {
                        if (value.from == "<?php echo e(auth()->user()->id); ?>") {
                            html += '<div class="d-flex flex-row justify-content-end mb-4">';
                            html += '<div class="p-3 me-3 col-md-6 border rounded rounded-full bg-white border-2 shadow">';
                            html += '<p class="small mb-0 text-wrap col-md-12 chat">' + value.message + '</p>';
                            html += '</div>';
                            html += '</div>';
                        } else {
                            html += '<div class="d-flex flex-row justify-content-start mb-4">';
                            html += '<div class="p-3 ms-3 col-md-6 border rounded rounded-full bg-gradient-light border-2 shadow">';
                            html += '<p class="small mb-0 text-wrap col-md-12 chat">' + value.message + '</p>';
                            html += '</div>';
                            html += '</div>';

                            $.ajax({
                                url: "<?php echo e(route('readChat')); ?>",
                                type: "post",
                                data: {
                                    _token: "<?php echo e(csrf_token()); ?>",
                                    id: value.id
                                },
                                dataType: "json",
                                success: function(res) {
                                    // console.log(res);
                                }
                            })
                        }
                    });
                    $('.containerBubble').html(html);
                    $(".containerBubble").animate({ scrollTop: 20000000 }, "slow");
                }
            })
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/chat/room-cust.blade.php ENDPATH**/ ?>