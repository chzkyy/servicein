

    <ul class="navbar-nav ml-auto">
        
        <li class="nav-item dropdown no-arrow mx-1">
            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw" style="color: #fff;"></i>
                
                <span class="badge badge-danger badge-counter" id="notif_count"></span>
            </a>
            
            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header rounded mt-0 bg-warning text-white">
                    Notification Center
                </h6>
                <div id="notif_list">
                </div>
                <a class="dropdown-item text-center small text-gray-500" href="<?php echo e(route('notification')); ?>">Show All
                    Notification</a>
            </div>
        </li>

        
        <li class="nav-item mx-1">
            <a class="nav-link" href="<?php echo e(route('admin-chat')); ?>" id="messagesDropdown">
                <i class="fas fa-envelope fa-fw" style="color: #fff"></i>
                
                <span class="badge badge-danger badge-counter" id="message_count"></span>
            </a>
        </li>

        <div class="topbar-divider d-none d-sm-block"></div>

        
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile mr-2 rounded-circle" src="<?php echo e(url('../dashboard/img/undraw_profile.svg')); ?>">
                <span class="mr-2 d-none d-lg-inline text-white small font-weight-bold"><?php echo e(Auth::user()->username); ?></span>
            </a>
            
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?php echo e(route('profile.admin')); ?>">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    Profile
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Logout
                </a>

            </div>
        </li>

    </ul>

</nav>

<?php /**PATH C:\laragon\www\servicein\resources\views/includes/adminDashboard/navbar.blade.php ENDPATH**/ ?>