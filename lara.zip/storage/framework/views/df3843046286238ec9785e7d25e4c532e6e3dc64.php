<?php $__env->startSection('title'); ?>
    <?php echo e(__('Profile')); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <section>
        <div class="container-fluid">
            <div class="container">
                <div class="col-md-12">
                    <?php if(session('success')): ?>
                        <div class="col-md-8 mt-5 pt-5">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <strong><?php echo e(__('Success')); ?>!</strong> <?php echo e(session('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        </div>
                    <?php endif; ?>

                    <div class="row mt-4">
                        <div class="col-sm-12 col-md-3 offset-md-1 pt-5 mt-5">
                            <div class="card shadow border d-flex justify-content-center align-items-center">
                                <div class="card-body">

                                    <?php if($avatar == null): ?>
                                        <img src="<?php echo e(asset('assets/img/profile_picture.png')); ?>"
                                            class="img-fluid card-img d-block mx-auto object-fit-none" alt="profile_picture"
                                            style="width: auto; height: 150px;">
                                    <?php elseif($avatar != null): ?>
                                        <img src="<?php echo e($avatar); ?>" class="img-fluid card-img d-block mx-auto object-fit-none"
                                            alt="profile_picture" style="width: auto; height: 150px;">
                                    <?php endif; ?>

                                    <div class="d-flex justify-content-center align-items-center">
                                        <a href="<?php echo e(route('edit.profile')); ?>" class="btn btn-link btn-sm mt-3">
                                            <small>
                                                <i class="fa-solid fa-pen-to-square"></i> Edit Profile
                                            </small>
                                        </a>
                                    </div>

                                    <div class="d-flex justify-content-center align-items-center">
                                        <?php if(Auth::user()->password != NULL): ?>
                                            <a href="<?php echo e(route('change-password')); ?>" class="btn btn-link btn-sm"><i class="fa-solid fa-lock-open">
                                                <small>
                                                    </i> <?php echo e(__("Change Password")); ?>

                                                </small>
                                            </a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            

                            <div class="mt-3 d-flex justify-content-center align-items-center">
                                <a href="<?php echo e(route('list-device')); ?>" class="btn btn-custome btn-sm mt-2">My Device List</a>
                            </div>

                            <div class="d-none d-md-flex justify-content-center align-items-center b-profile txt-gold mb-5">
                                <div class="chart-container">
                                    <div class="gauge-wrap" data-value="<?php echo e($percentage); ?>">
                                        <span class="percent txt-gold fw-semibold"><?php echo e($percentage); ?>%</span>
                                    </div>
                                </div>
                            </div>

                            <div class="d-block d-md-none progress mt-5 mb-2">
                                <div class="progress-bar bg-custome" role="progressbar" style="width: <?php echo e($percentage); ?>%;"
                                    aria-valuenow="<?php echo e($percentage); ?>" aria-valuemin="0" aria-valuemax="100">
                                    <?php echo e($percentage); ?>%</div>
                            </div>

                            <div class="d-flex justify-content-center align-items-center txt-gold mb-5">
                                <span class="fw-semibold text-bar">Profile Completion</span>
                            </div>

                        </div>

                        <div class="col-md-7 pt-md-5 mt-md-5">
                            <div class="card shadow border">
                                <div class="card-body txt-third m-4">
                                    
                                    <div class="fullname mb-4">
                                        <img src="<?php echo e(url('assets/img/Avatar.png')); ?>" alt="Avatar" class="img-fluid">
                                        <span class="mx-2 fw-semibold">
                                            <?php echo e(Auth::user()->username); ?>

                                        </span>
                                    </div>

                                    
                                    <div class="h5 txt-gold my-4">General Information</div>

                                    <div class="detail-profile">
                                        <div class="fullname mb-2">
                                            <span class="fw-semibold">Fullname</span>
                                            <div class="data">
                                                <span><?php echo e($customer->fullname); ?></span>
                                            </div>
                                        </div>

                                        <div class="gender mb-2">
                                            <span class="fw-semibold">Gender</span>
                                            <div class="data">
                                                <span><?php echo e($customer->gender); ?></span>
                                            </div>
                                        </div>

                                        <div class="dob mb-2">
                                            <span class="fw-semibold">Birth Date</span>
                                            <div class="data">
                                                <?php if( $customer->dob == null ): ?>
                                                    <?php echo e(__('-')); ?>

                                                <?php else: ?>
                                                    <span><?php echo e(date('d/m/Y', strtotime($customer->dob))); ?></span>
                                                <?php endif; ?>
                                            </div>
                                        </div>

                                    </div>

                                    <hr class="border border-gold border-1 opacity-50 mx-4">

                                    
                                    <div class="h5 txt-gold my-4">Contact Detail</div>

                                    <div class="detail-profile">
                                        <div class="phone-number mb-2">
                                            <span class="fw-semibold">Phone Number</span>
                                            <div class="data">
                                                <span>
                                                    <?php echo e(preg_replace('/\d{3}/', '($0) - ', str_replace('.', null, trim($customer->phone_number)), 1)); ?>

                                                </span>
                                            </div>
                                        </div>

                                        <div class="email mb-2">
                                            <span class="fw-semibold">Email</span>
                                            <div class="data">
                                                <span><?php echo e(Auth::user()->email); ?></span>
                                            </div>
                                        </div>

                                        <div class="cust_addrs mb-2">
                                            <span class="fw-semibold">Address</span>
                                            <div class="data">
                                                <span><?php echo e($customer->cust_address); ?></span>
                                            </div>
                                        </div>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('additional-script'); ?>
    <script>
        $(document).ready(function() {
            $('.gauge-wrap').simpleGauge({
                width:'120',
                hueLow:'0',
                hueHigh:'0',
                saturation:'0%',
                lightness:'0%',
                gaugeBG:'#fff',
                parentBG:'#fff'
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\servicein\resources\views/customer/profile/index.blade.php ENDPATH**/ ?>